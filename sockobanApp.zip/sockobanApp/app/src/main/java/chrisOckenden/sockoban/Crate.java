package chrisOckenden.sockoban;

public class Crate extends Placeable {
	
	public Crate(int x, int y) {
		super(x, y);
		this.symbol = 'x';
	}
	
	public String toString() {
		 String symbolString = String.valueOf(symbol);
		 return symbolString;	
	}
}
