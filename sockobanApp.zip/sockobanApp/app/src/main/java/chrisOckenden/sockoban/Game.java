package chrisOckenden.sockoban;
/**
 * 
 */

import android.graphics.Point;
import java.util.ArrayList; // Resizable-array implementation of the List interface
import java.util.Iterator;
import java.util.List; // interface of an ordered collection


public class Game {
	protected int levelCount = 0;
	protected String currentLevelName;
	protected String noLevel = "no levels";
	protected ArrayList<Level> levelArray = new ArrayList<Level>();
	protected int currentLevelSelected = 0;

	// Calls from the MoveMethod Class to processes a move direction.
	public void move(Direction direction) {
		MoveMethods moveMethod = new MoveMethods();
		Level currentLevel = moveMethod.getCurrentLevel(levelArray, currentLevelSelected);
		Placeable currentWorkerTile = moveMethod.getWorkerTile(currentLevel);
		Point workerCurrentPoint = moveMethod.getWorkerCurrentPlace(currentWorkerTile);
		Point workerDestinationPoint = moveMethod.getworkerDestinationPoint(direction, workerCurrentPoint);
		Placeable workerDestinationTile = moveMethod.getWorkerDestinationTile(workerDestinationPoint, currentLevel);
		moveMethod.makeMove(workerDestinationTile, workerDestinationPoint, direction, currentWorkerTile, currentLevel);
	}

	// Moving object enumerator.
	public enum Direction {
		UP,
		RIGHT,
		DOWN,
		LEFT;
	}

	public int getLevelCount() {
		return this.levelCount;
	}

	@Override // String returns the required info to see moves been made on the screen.
	public String toString() {
		MoveMethods moveMethod = new MoveMethods();
		Level currentLevel = moveMethod.getCurrentLevel(levelArray, this.currentLevelSelected);
		return currentLevel.toString();
	}

	public String getCurrentLevelName() {
		if(this.levelCount == 0) {
			return this.noLevel;
		}
		else {
			return this.currentLevelName;
		}
	}

	// List that holds the level names, if a level is added to the Game then the list is updated.
	public List<String> getLevelNames() {

		// iterate through levelArray and get the level names
		Iterator<Level> itr=levelArray.iterator();
		List<String> levelNamesList =new ArrayList<String>();

		while(itr.hasNext()){
			Level level=(Level)itr.next();
			levelNamesList.add(level.name);
		}
		// add the level names into a List<String> called whatever.
		return levelNamesList;
	}

	// Create and add a level to the level array.
	public void addLevel(String name, int width, int height, String rawLevelString) {
		Level level = new Level(name, height, width, rawLevelString);
		levelArray.add(level);
		this.levelCount++;
		this.currentLevelName = level.name;
	}

	public Placeable[][] getPlaceabales() {
		MoveMethods moveMethod = new MoveMethods();
		Level currentLevel = moveMethod.getCurrentLevel(levelArray, this.currentLevelSelected);
		return currentLevel.getAllPlaceables();
	}

	public int[] getDimensions() {
		// Gets the width and height of the current level.
		MoveMethods moveMethod = new MoveMethods();
		Level currentLevel = moveMethod.getCurrentLevel(levelArray, this.currentLevelSelected);
		int width = currentLevel.getWidth();
		int height = currentLevel.getHeight();
		int[] array = {height, width};
		return array;
	}

	public int getTargetCount() {
		MoveMethods moveMethod = new MoveMethods();
		Level currentLevel = moveMethod.getCurrentLevel(levelArray, this.currentLevelSelected);
		return currentLevel.targetCount();
	}

	public void setCurrentLevel(int level) {
		this.currentLevelSelected = level;
	}

	public int getCompletedTargets() {
		MoveMethods moveMethod = new MoveMethods();
		Level currentLevel = moveMethod.getCurrentLevel(levelArray, this.currentLevelSelected);
		return currentLevel.getCompletedCount();
	}

	public int getMoveCount() {
        MoveMethods moveMethod = new MoveMethods();
        Level currentLevel = moveMethod.getCurrentLevel(levelArray, this.currentLevelSelected);
        return currentLevel.moveCount;
    }

	public int getCurrentLevelIndex() {
		return this.currentLevelSelected-1;
	}

	public int getLevelAmount() {
		return this.levelArray.size();
	}
}

