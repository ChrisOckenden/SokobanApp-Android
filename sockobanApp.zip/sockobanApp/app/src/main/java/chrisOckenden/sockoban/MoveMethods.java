package chrisOckenden.sockoban;

import android.graphics.Point;
import java.util.ArrayList;
import java.util.Arrays;

import chrisOckenden.sockoban.Game.Direction;

public class MoveMethods {
	String[] workerChars = {"w", "W"};
	
	public Placeable getWorkerTile(Level level) {
		Placeable currentWorkerTile = null;
		
		for (int row = 0; row < level.allPlaceables.length; row++) {
			for (int column = 0; column < level.allPlaceables[row].length; column++) {				
				if ( Arrays.asList(workerChars).contains(level.allPlaceables[row][column].toString())) {
					currentWorkerTile = level.allPlaceables[row][column];
				}
			}
		}
		return currentWorkerTile; 
	}
	
	public Point getworkerDestinationPoint(Direction direction, Point currentPosition) {
		int x = currentPosition.x;
		int y = currentPosition.y;
		Point workerDestinationPoint = new Point(x,y);

		 switch (direction) {
		 case UP: {
			 workerDestinationPoint.offset(-1,0);
			break;                       
          }
		case DOWN: {
			workerDestinationPoint.offset(1,0);
			break;
		}
			
		case LEFT: {
			workerDestinationPoint.offset(0,-1);
			break;
		}

		case RIGHT: {
			workerDestinationPoint.offset(0,1);
			break;			
		}
		
		 }
		
		return workerDestinationPoint;
	}

	
	public Placeable getWorkerDestinationTile(Point workerDestinationPoint, Level currentLevel) {
		int x = (int) workerDestinationPoint.x;
		int y = (int) workerDestinationPoint.y;
		
		Placeable workerDestinationTile = currentLevel.allPlaceables[x][y]; 
		return workerDestinationTile;
	}

	public Level getCurrentLevel(ArrayList<Level> levelArray, int selectedCurrentLevel) {
		Level currentLevel = levelArray.get(selectedCurrentLevel-1);  // Get the current level
		return currentLevel;
	}
	
	public Point getWorkerCurrentPlace(Placeable currentWorkerTile) {
		 Point currentWorkerPlace = currentWorkerTile.position;
		 return currentWorkerPlace;
		
	}
	
	public void makeMove(Placeable workerDestinationTile, Point workerDestinationPoint, Direction direction, Placeable currentWorkerTile, Level currentLevel) {
		MoveMethods mover = new MoveMethods();
		Crate crate = new Crate(1,1);
		Worker worker = new Worker(1,1);
		
		
		// Worker attempts to move on a tile with nothing on it.
		if((workerDestinationTile.toString()).equals(".") ||(workerDestinationTile.toString()).equals("+")) {
			
			// If the currentWorker is on a tile, remove it from the tile.
			if(currentWorkerTile instanceof Empty) {
				((Empty) currentWorkerTile).removeItem();
			}
			
			// Else the currentWorker is on a target, remove it from the tile.
			else { 
				((Target) currentWorkerTile).removeItem();
			}
		
			// If the destination tile is an empty type put the worker on it.
			if(workerDestinationTile instanceof Empty) {			
				((Empty) workerDestinationTile).addWorker(worker);
			}
			
			// Else the destination tile is a Target type and put the work on that.
			else { 			
				((Target) workerDestinationTile).addWorker(worker);
			}							
		}
		
		// Worker attempts to move on a tile that has a crate on it.
		else if((workerDestinationTile.toString()).equals("x") || (workerDestinationTile.toString()).equals("X") ) {
					
			Point crateDestinationPoint = mover.getworkerDestinationPoint(direction, workerDestinationPoint);
			Placeable crateDestinationTile = mover.getWorkerDestinationTile(crateDestinationPoint, currentLevel);
			
			// If the crate destination point has nothing on it then move it onto the tile.
			if((crateDestinationTile.toString()).equals(".")|| (crateDestinationTile.toString()).equals("+") ) {

				
				// If the crate is on an empty tile get the crate from where it is.
				if(workerDestinationTile instanceof Empty) {
					((Empty) workerDestinationTile).removeItem();
				}
				
				// Else the crate is from a target type tile and get it from that.
				else { 
					((Target) workerDestinationTile).removeItem();
				}
				
				// If the destination tile is an empty type put the crate on it.
				if(crateDestinationTile instanceof Empty) {			
					((Empty) crateDestinationTile).addCrate(crate);
				}
				
				// Else the destination tile is a Target type and put the crate on that.
				else { 			
					((Target) crateDestinationTile).addCrate(crate);
				}
				
				// If the worker is on an empty tile get take them off it.
				if(currentWorkerTile instanceof Empty) {
					((Empty) currentWorkerTile).removeItem();
				}
				
				// Else the worker on a target tile get them off it.
				else { 
					((Target) currentWorkerTile).removeItem();
				}
				
				// If the destination worker tile is an empty type put the worker on it.
				if(workerDestinationTile instanceof Empty) {			
					((Empty) workerDestinationTile).addWorker(worker);
				}
				
				// Else the destination tile is a Target type and put the worker on that.
				else { 			
					((Target) workerDestinationTile).addWorker(worker);
				}
				
				
			}				
		}
			
		else {
			// Do nothing for less of a better setup.
		}
		
		currentLevel.addAMove();
	}
}
