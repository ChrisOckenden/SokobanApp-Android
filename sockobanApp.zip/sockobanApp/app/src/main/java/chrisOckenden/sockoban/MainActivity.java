package chrisOckenden.sockoban;

import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import java.util.List;

import chrisOckenden.sockoban.Game.Direction;

public class MainActivity extends AppCompatActivity {
    Game game = new Game();
    int levelRows;
    int levelColumns;
    Placeable[][] gamePlaceables;
    ImageView[][] imageViews;
    int heightOffset;
    int widthOffset;
    int viewSideLength;
    int targetCount;
    List<String> allLevelNames;
    int moveCount;
    int targetsCompleted;
    long[] levelTimes;
    Chronometer chronometer;
    boolean[] completedField;
    int workerRow = 0;
    int workerCol = 0;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // setup and initialise the game and level ----------------------------
        MediaPlayer startGameSound = MediaPlayer.create(this, R.raw.start_up);
        final MediaPlayer changeLevelSound = MediaPlayer.create(this, R.raw.change_level);
        startGameSound.start();
        chronometer = findViewById(R.id.chronometer);

        game.addLevel("Level1", 7, 6,
                "#######" +
                             "#w....#" +
                             "#.....#" +
                             "#..+..#" +
                             "#.....#" +
                             "#######");

        int startLevel = 1;
        game.setCurrentLevel(startLevel);
        levelSet();

        levelTimes = new long[game.getLevelAmount()];
        completedField = new boolean[game.getLevelAmount()];
        chronometer.setBase(SystemClock.elapsedRealtime());
        chronometer.start();

            }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    public void levelSet() {
        // If the game has finished control the timer and set the completed field to true.
        if (game.getCompletedTargets() == game.getTargetCount()) {
            chronometer.stop();
            levelTimes[game.getCurrentLevelIndex()] = (SystemClock.elapsedRealtime() - chronometer.getBase());
            completedField[game.getCurrentLevelIndex()] = true;
        }

        MediaPlayer completedTargetSound = MediaPlayer.create(this, R.raw.box_on_slot);
        MediaPlayer moveMadeSound = MediaPlayer.create(this, R.raw.make_move);
        final int targetsCompletedCompare = targetsCompleted;
        final int moveCountCompare = moveCount;
        ConstraintLayout mainLayout = findViewById(R.id.main_activity_layout);

        TextView textView1 = (TextView) findViewById(R.id.targetCount);
        targetCount = game.getTargetCount();
        String targetCountMsg = "Targets: " + targetCount;
        textView1.setText(targetCountMsg);

        TextView textView2 = (TextView) findViewById(R.id.moveCount);
        moveCount = game.getMoveCount();
        if (moveCountCompare < moveCount) {
            moveMadeSound.start();
        }

        String moveCountMsg = "Move count: " + moveCount;
        textView2.setText(moveCountMsg);

        TextView textView3 = (TextView) findViewById(R.id.targetsCompleted);
        targetsCompleted = game.getCompletedTargets();
        if (targetsCompletedCompare < targetsCompleted) {
            completedTargetSound.start();
        }

        String targetsCompletedMsg = "Completed targets: " + targetsCompleted;
        textView3.setText(targetsCompletedMsg);

        levelRows = (game.getDimensions())[0];
        levelColumns = (game.getDimensions())[1];
        gamePlaceables = game.getPlaceabales();
        imageViews = new ImageView[levelRows][levelColumns];

        // https://stackoverflow.com/questions/4743116/get-screen-width-and-height-in-android
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        // set the offsets to center the maze for landscape and portrait -----------start-----
        if (displayMetrics.widthPixels < displayMetrics.heightPixels) {
            viewSideLength = (int) ((displayMetrics.widthPixels) / levelColumns);
            heightOffset = (int) (0.8 * (displayMetrics.heightPixels - viewSideLength * levelRows) / 2);
            widthOffset = 0;
        } else if (displayMetrics.widthPixels > displayMetrics.heightPixels) {
            viewSideLength = (int) (((displayMetrics.heightPixels) / levelRows) * .80);
            //widthOffset = (displayMetrics.widthPixels - viewSideLength * levelColumns) / 2;
            widthOffset = 0;
            heightOffset = 0;
        } else {
            viewSideLength = (int) ((displayMetrics.widthPixels) / levelColumns);
            widthOffset = (displayMetrics.widthPixels - viewSideLength * levelColumns) / 2;
            heightOffset = (displayMetrics.heightPixels - viewSideLength * levelRows) / 2;
        }
        // set the offsets to center the maze for landscape and portrait -----------end-----

        ConstraintSet constraintSet = new ConstraintSet();

        // set the images on screen ---------------start----------------
        for (int row = 0; row < levelRows; ++row) {
            for (int col = 0; col < levelColumns; ++col) {
                imageViews[row][col] = new ImageView(this);
                imageViews[row][col].setId(View.generateViewId());

                if ((gamePlaceables[row][col].toString()).equals("#")) {
                    imageViews[row][col].setImageResource(R.drawable.wall);
                } else if ((gamePlaceables[row][col].toString()).equals(".")) {
                    imageViews[row][col].setImageResource(R.drawable.empty);
                } else if ((gamePlaceables[row][col].toString()).equals("x")) {
                    imageViews[row][col].setImageResource(R.drawable.block);
                } else if ((gamePlaceables[row][col].toString()).equals("+")) {
                    imageViews[row][col].setImageResource(R.drawable.emptyslot);
                } else if ((gamePlaceables[row][col].toString()).equals("w")) {
                    workerRow = row;
                    workerCol = col;
                    imageViews[row][col].setImageResource(R.drawable.robot);
                } else if ((gamePlaceables[row][col].toString()).equals("X")) {
                    imageViews[row][col].setImageResource(R.drawable.slotblock);
                }
                else {
                    // ((gamePlaceables[row][col].toString()).equals("W"))
                    imageViews[row][col].setImageResource(R.drawable.robot_on_target);

                }

                // set the constraints for the images on screen ----------start--------------
                imageViews[row][col].setLayoutParams(new ConstraintLayout.LayoutParams(viewSideLength, viewSideLength));
                imageViews[row][col].getLayoutParams().height = viewSideLength;
                mainLayout.addView(imageViews[row][col]);
                constraintSet.clone(mainLayout);

                if (row == 0 && col == 0) {
                    constraintSet.connect(imageViews[row][col].getId(), ConstraintSet.TOP, mainLayout.getId(), ConstraintSet.TOP, heightOffset);
                    constraintSet.connect(imageViews[row][col].getId(), ConstraintSet.LEFT, mainLayout.getId(), ConstraintSet.LEFT, widthOffset);
                } else if (col != 0) {
                    constraintSet.connect(imageViews[row][col].getId(), ConstraintSet.TOP, imageViews[row][col - 1].getId(), ConstraintSet.TOP, 0);
                    constraintSet.connect(imageViews[row][col].getId(), ConstraintSet.LEFT, imageViews[row][col - 1].getId(), ConstraintSet.RIGHT, 0);
                } else {
                    //  ( row != 0 && col == 0)
                    constraintSet.connect(imageViews[row][col].getId(), ConstraintSet.TOP, imageViews[row - 1][col].getId(), ConstraintSet.BOTTOM, 0);
                    constraintSet.connect(imageViews[row][col].getId(), ConstraintSet.LEFT, imageViews[row - 1][col].getId(), ConstraintSet.LEFT, 0);
                }
                constraintSet.applyTo(mainLayout);
                // set the constraints for the images on screen ----------end--------------
                // set the images on screen ---------------end----------------
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    public void move(View view) {
        int viewId = view.getId();

        // Set game move to the user direction input --------start-------
        if  (viewId == R.id.buttonRight && workerCol <= 4) {
            game.move(Direction.RIGHT);
        }

        /* else if (workerRow == 6 && workerCol == 5) {
            // send worker back to the start position as has reached the end
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.UP);
            game.move(Direction.UP);
            game.move(Direction.UP);
        }
        */
        else if  (viewId == R.id.buttonRight && workerCol == 5 && workerRow <= 3) {
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.DOWN);
        }

        else {
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.LEFT);
            game.move(Direction.UP);
            game.move(Direction.UP);
            game.move(Direction.UP);
        }

        levelSet();
        // Set game move to the user direction input --------end-------
    }

    public void timerSetter(int spinner_pos) {
        // If the completed field for the level has already been set, add no time.
        if (completedField[game.getCurrentLevelIndex()] != true) {
            chronometer.stop();
            levelTimes[game.getCurrentLevelIndex()] = (SystemClock.elapsedRealtime() - chronometer.getBase());
        }
        // If the completed field has not been set for the switched to level, start timer at time where it was last played.
        if (completedField[spinner_pos] != true) {
            chronometer.setBase(SystemClock.elapsedRealtime() - levelTimes[spinner_pos]);
            chronometer.start();
        }
        // If the completed field has been set for the switched too level only show the finished time, do not start it.
        else {
            chronometer.setBase(SystemClock.elapsedRealtime() - levelTimes[spinner_pos]);
        }

    }
}
