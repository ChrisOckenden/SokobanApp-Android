package chrisOckenden.sockoban;

import java.util.ArrayList;

public class Maze {
    private ArrayList mazeMap = new ArrayList<>();
    private int theseusPos;

//    public int getTheseusPos() {
//        return theseusPos;
//    }

//    public void setTheseusPos(int theseusPos) {
//        this.theseusPos = theseusPos;
//    }

    public ArrayList getMazeMap() {
        return mazeMap;
    }
}

