package chrisOckenden.sockoban;

import android.graphics.Point;

public abstract class Placeable {	
	protected  char symbol;
	protected Point position;
	
	public abstract String toString();
	
	public Placeable(int x, int y) {
		this.position = new Point (x, y);
	}

}
