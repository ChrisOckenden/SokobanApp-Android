package chrisOckenden.sockoban;

public class Level {
	protected String name;
	protected int height;
	protected int width;
	protected Placeable[][] allPlaceables; // For storing the 2D Sockoban board items.
	protected int moveCount = 0;
	protected Target target = new Target(1,1);
	protected int targetCount = 0;
	protected int completedCount = 0;
	
	
	public Level(String name, int height, int width, String rawLevelString) {
		this.name = name;
		this.height = height;
		this.width = width;
		int countString = 0;
		this.allPlaceables = new Placeable[height][width]; 
		
		// Make the level Placeables and put them into the allPlaceables.
		for (int x = 0; x < height; x++ ) {
			for (int y = 0; y < width; y++) {

				char symbol = rawLevelString.charAt(countString); 
			    Placeable newPlaceable = makePlaceable(x, y, symbol); 
			    this.allPlaceables[x][y] = newPlaceable; 
			    countString++;	
			}				
		}
		
		// Calculate the levels target count.
		for (int row = 0; row < allPlaceables.length; row++) {
			for (int column = 0; column < allPlaceables[row].length; column++) {
				if (allPlaceables[row][column] instanceof Target) {
					this.targetCount++;
				}
			}
		}
	}
	
	// Take the string data symbols from the level and set them as Placeable class objects.
	protected Placeable makePlaceable(int x, int y, char symbol) {
	     Placeable placeablePiece = null;
	     
	     switch (symbol) {
	          case '#': {
	        	  placeablePiece = new Wall(x, y);
	        	  break;                       
	           }
	          
	          case '.': {
	        	  placeablePiece = new Empty(x, y);
	        	  break;
	           }
	          
	          case '+': {
	        	  placeablePiece = new Target(x, y);
	        	  break;
	           }
	                    
	          case 'x': {
	        	  // composite placeable contains a crate on an empty.
	        	  Empty newEmpty = new Empty(x, y);
	        	  Crate newCrate = new Crate(x, y);
	        	  newEmpty.addCrate(newCrate);
	        	  placeablePiece = newEmpty;
	        	  break;      	            
	           }
	          
	          case 'w': {
	        	  // composite placeable contains a worker on an empty.
	        	  Empty newEmpty = new Empty(x, y);
	              Worker newWorker = new Worker(x, y);
	              newEmpty.addWorker(newWorker);   
	              placeablePiece = newEmpty;
	              break;
	           }
	          
	          case 'W': {
	        	  // Composite placeable contains a worker on an target.
	        	  Target newTarget = new Target(x, y);
	              Worker newWorker = new Worker(x, y);
	              newTarget.addWorker(newWorker);  
	              placeablePiece = newTarget;
	              break;
	           }
	          
	          case 'X': {
	        	  // Composite placeable contains a crate on an target.
	        	  Target newTarget = new Target(x, y);
	              Crate newCrate = new Crate(x, y);
	              newTarget.addCrate(newCrate);  
	              placeablePiece = newCrate;
	              break;
	           }               	             
	    } 	
	     
	     return placeablePiece;	 
	}	

	public int getWidth() {
		return this.width;		
	}
	
	public int getHeight() {
		return this.height;		
	}
	
	public void addAMove() {
		this.moveCount++;		
	}
	
	
	public int getMoveCount() {
		return this.moveCount;		
	}
	
	public String getName() {
		return this.name;		
	}
	
	public int getCompletedCount() {
		this.completedCount=0;
		for (int row = 0; row < this.height; row++) {
			for (int column = 0; column < this.width; column++) {
				if((allPlaceables[row][column].toString()).equals("X")) {
					completedCount++;
				}
			}
		}
		return this.completedCount;		
	}
	
	public int targetCount() {		
		return this.targetCount; 
	}
	
	@Override // String returns the required info to see moves been made on the screen.
	public String toString() {
		String levelRow = "";
		String levelInfo = "";		
		
		for (int row = 0; row < this.height; row++) {
			for (int column = 0; column < this.width; column++) {
				levelRow = levelRow + allPlaceables[row][column].toString();
			}
			levelInfo = levelInfo + levelRow +"\n";
			levelRow = "";
		}
		return this.name + "\n" + levelInfo + "move " + this.getMoveCount() + 
				"\n" + "completed " + this.getCompletedCount() + " of " + 
				this.targetCount() + "\n"; 	
	}
	public Placeable[][] getAllPlaceables() {
		return this.allPlaceables;
	}
}
