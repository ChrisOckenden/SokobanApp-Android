package chrisOckenden.sockoban;

public class Empty extends Placeable {
	
	public Empty(int x, int y) {
		super(x, y);
		this.symbol = '.';
	}
	
	public String toString() {
		 String symbolString = String.valueOf(symbol);
		 return symbolString;
	}
	
	public void addWorker(Worker worker) {
		this.symbol = 'w';
	}
	
	public void addCrate(Crate crate) {
		this.symbol = 'x';
	}
	
	public void removeItem() {
		this.symbol = '.';
	}
}
