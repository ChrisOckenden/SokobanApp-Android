package chrisOckenden.sockoban;

public class Wall extends Placeable {
	protected final char wall = '#';
	
	public Wall(int xPosition, int yPosition) {
		super(xPosition, yPosition);
		this.symbol = this.wall;
	}
	
	public String toString() {
		 String symbolString = String.valueOf(symbol);
		 return symbolString;
	}
}
