package chrisOckenden.sockoban;

public class Target extends Placeable {

	public Target(int x, int y) {
		super(x, y);
		this.symbol = '+';
	}

	public String toString() {
		 String symbolString = String.valueOf(symbol);
		 return symbolString;	
	}	
	
	public void addWorker(Worker worker) {
		this.symbol = 'W';
	}
	
	public void addCrate(Crate crate) {
		this.symbol = 'X';
	}
	
	public void removeItem() {
		this.symbol = '+';
	}
	
}