package chrisOckenden.sockoban;

public class Worker extends Placeable {	
	
	public Worker(int xPosition, int yPosition) {
		super(xPosition, yPosition);
		this.symbol = 'w';
	}
	
	public String toString() {
		 String symbolString = String.valueOf(symbol);
		 return symbolString;	
	}	
}
